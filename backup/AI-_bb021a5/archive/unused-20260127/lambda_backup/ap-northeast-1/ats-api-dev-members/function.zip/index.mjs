import { Client } from 'pg';

const ALLOW_HEADERS = 'content-type,authorization';
const ALLOW_METHODS = 'GET,OPTIONS';

function buildCorsHeaders(origin) {
  const allowOrigin = origin || '*';
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Headers': ALLOW_HEADERS,
    'Access-Control-Allow-Methods': ALLOW_METHODS,
    'Access-Control-Max-Age': '86400',
    Vary: 'Origin'
  };
}

function getDbConfig() {
  const {
    DB_HOST,
    DB_PORT,
    DB_NAME,
    DB_USER,
    DB_PASSWORD,
    DB_SSL
  } = process.env;

  if (!DB_HOST || !DB_NAME || !DB_USER || !DB_PASSWORD) {
    throw new Error('Missing DB env (DB_HOST/DB_NAME/DB_USER/DB_PASSWORD)');
  }

  return {
    host: DB_HOST,
    port: Number(DB_PORT) || 5432,
    database: DB_NAME,
    user: DB_USER,
    password: DB_PASSWORD,
    ssl: DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined
  };
}

function normalizeUser(row) {
  const role = row.role || (row.is_admin ? 'admin' : 'member');
  return {
    id: String(row.id),
    name: row.name || '',
    email: row.email || '',
    role
  };
}

export const handler = async (event) => {
  const method = event.requestContext?.http?.method || event.httpMethod || 'GET';
  const origin = event.headers?.origin || event.headers?.Origin || '';
  const corsHeaders = buildCorsHeaders(origin);

  if (method === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders, body: '' };
  }

  if (method !== 'GET') {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Method Not Allowed' })
    };
  }

  const client = new Client(getDbConfig());

  try {
    await client.connect();

    let rows = [];
    try {
      const result = await client.query(
        'SELECT id, name, email, role, is_admin FROM users ORDER BY created_at DESC'
      );
      rows = result.rows;
    } catch (error) {
      if (error?.code === '42703') {
        const result = await client.query(
          'SELECT id, name, email, role FROM users ORDER BY created_at DESC'
        );
        rows = result.rows;
      } else {
        throw error;
      }
    }

    const items = rows.map(normalizeUser);

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ items })
    };
  } catch (error) {
    console.error('members error:', error);
    return {
      statusCode: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: 'Internal Server Error' })
    };
  } finally {
    try {
      await client.end();
    } catch {
      // ignore
    }
  }
};
